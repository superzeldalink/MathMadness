PRESS 4 ON NUMPAD TO TRUE
PRESS 6 ON NUMPAD TO FALSE

------------------------------------------------------------------
THANKS FOR PLAYING !!!

CONTACT:
FACEBOOK: facebook.com/superzeldalink.link
EMAIL: superzeldalink@gmail.com