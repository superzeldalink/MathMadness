VERSION 2 :)
VERY HARD mode only :))))))
4 -> LEFT BUTTON
6 -> RIGHT BUTTON